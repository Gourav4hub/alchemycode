export const LOAD_CATEGORIES = "loadCategories"
export const ADD_CATEGORY = "addCategory"

export const LOAD_BRANDS = "loadBrands"

export const LOAD_PRODUCTS = "loadProducts"
export const ADD_PRODUCT = "addProduct"
export const CHANGE_PRODUCT_STATUS = "changeProductStatus"