export default [
 {pid:101,name:'Bravia V1',company:'Sony',price:89999,discount:2500,image:'/imgs/tv1.jpg',category:'tv'},
 {pid:102,name:'OLED P1',company:'Samsung',price:49599,discount:0,image:'/imgs/tv2.jpg',category:'tv'},
 {pid:103,name:'LG Slim',company:'LG',price:29899,discount:1000,image:'/imgs/tv3.jpg',category:'tv'},
 {pid:104,name:'OLED P2',company:'Samsung',price:19859,discount:200,image:'/imgs/tv4.jpg',category:'tv'},

 {pid:105,name:'Samsung Cool',company:'Samsung',price:45899,discount:2000,image:'/imgs/ac1.jpg',category:'ac'},
 {pid:106,name:'LG Himalaya',company:'LG',price:59899,discount:0,image:'/imgs/ac2.jpg',category:'ac'},
 {pid:110,name:'Samsung C3',company:'Samsung',price:45899,discount:2000,image:'/imgs/ac1.jpg',category:'ac'},
 {pid:111,name:'Panasonic P2',company:'Panasonic',price:45896,discount:100,image:'/imgs/ac2.jpg',category:'ac'},

 {pid:107,name:'Usha A1',company:'Usha',price:1299,discount:500,image:'/imgs/fan1.jpg',category:'fan'},
 {pid:108,name:'Bajaj Smart',company:'Bajaj',price:1899,discount:0,image:'/imgs/fan2.jpg',category:'fan'},
 {pid:109,name:'Orient PSPO',company:'Orient',price:2500,discount:0,image:'/imgs/fan3.jpg',category:'fan'},
 {pid:112,name:'Bajaj S2',company:'Bajaj',price:1258,discount:50,image:'/imgs/fan2.jpg',category:'fan'},
 {pid:112,name:'Orient P5',company:'Orient',price:1458,discount:100,image:'/imgs/fan3.jpg',category:'fan'}
]