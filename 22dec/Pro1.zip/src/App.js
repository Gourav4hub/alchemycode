import React from 'react'

import { First , Second} from './MyComponents'
import Demo from './MyComponents';

class App extends React.Component
{
    render()
    {
      var num = 100;
      return <div>
          <h1>My first ReactJS Component</h1>
          <b>Good Morning Everyone !</b>
          <br/>
          <b>Number : {num}</b>
          <hr/>
          <First/>          
          <Second/>
          <Demo/>
      </div>
    }
}

export default App;
