import React from 'react'

export default class Home extends React.Component
{
    render()
    {
        return <div>
            <h2>Home Component</h2>
            <img src="/imgs/img1.jpg"/>
        </div>
    }
}

